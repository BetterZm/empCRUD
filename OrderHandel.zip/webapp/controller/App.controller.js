sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/format/DateFormat",
	"OrderHandel/model/models",
	"../util/xlsx.full.min",
	"../util/cputils"
], function(Controller, MessageToast, JSONModel, Spreadsheet, DateFormat, models, Excel2Json, cputils) {
	"use strict";

	return Controller.extend("OrderHandel.controller.App", {
		
		onInit: function(){
			this.getView().setModel(new JSONModel([]));
		},
		
		onUploadExcel: function(oEvent) {
			this._handleUpload();
		},
		
		_handleUpload: function(fnDone) {
			//订单明细
			var _orderDetailUploader = this.getView().byId("orderDetail_FileUpload");
			if (_orderDetailUploader && !_orderDetailUploader.getValue()) {
				MessageToast.show("导入的订单不能为空，请修改后重试！", {
					at: sap.ui.core.Popup.Dock.CenterCenter
				});
				return;
			}

			var aOrderDetailCols = models.getOrderDetailCols();
			var oOrderDetail = {};
			this._parseExcel(_orderDetailUploader, aOrderDetailCols, function(excelData) {
				excelData.forEach(function(item) {
					var tid = item.tid;
					var replacedTitle = item.title.replace("交通联名卡", "").replace("全国通用交通联合版【预售】", "");
					var coveredTitle = replacedTitle + item.number;
					if (oOrderDetail.hasOwnProperty(tid)) {
						oOrderDetail[tid] = oOrderDetail[tid] + "," + coveredTitle;
					} else {
						oOrderDetail[tid] = coveredTitle;
					}
				});

				//console.log("订单明细: " + JSON.stringify(oOrderDetail));
			});

			//订单
			var _orderUploader = this.getView().byId("order_FileUpload");
			if (_orderUploader && !_orderUploader.getValue()) {
				MessageToast.show("导入的订单不能为空，请修改后重试！", {
					at: sap.ui.core.Popup.Dock.CenterCenter
				});
				return;
			}

			var aOrderCols = models.getOrderCols();
			var aReceiver = [];
			this._parseExcel(_orderUploader, aOrderCols, function(excelData) {
				excelData.forEach(function(item) {
					var tid = item.tid;
					var name = item.name;
					var address = item.address;
					var phone = item.phone;
					var title = oOrderDetail[tid];
					aReceiver.push({
						"tid": tid,
						"deliveryid": "",
						"name": name,
						"address": address,
						"phone": phone,
						"title": title
					});
				});

				console.log("订单: " + JSON.stringify(aReceiver));
				this.getView().setModel(new JSONModel(aReceiver));

				if (fnDone) {
					fnDone(aReceiver);
				}
			}.bind(this));
		},
		
		onUploadAndExport: function() {
			this._handleUpload(function(oExportData) {
				this._exportExcel(oExportData || []);
			}.bind(this));
		},

		onExportExcel: function() {
			this._exportExcel(this.getView().getModel().getData() || []);
		},
		
		_exportExcel: function(oExportData){
			var oSettings = {
				workbook: {
					columns: this.getTableColumns()
				},
				dataSource: oExportData,
				fileName: "终版@" + this._getNowFormatDate()
			};

			new Spreadsheet(oSettings).build().then(function() {
				console.log("Data Export finished");
			});
		},
		
		_parseExcel: function(oFileUploader, aTableColumns, fnDone) {
			var oDomRef = oFileUploader.getFocusDomRef();
			var oFile = oDomRef.files[0];
			if (!oFile) {
				MessageToast.show(this.oResourceBoundle.getText("UploadCheck"), {
					at: sap.ui.core.Popup.Dock.CenterCenter
				});
				return;
			}

			var isCSV = oFile.name.split(".").reverse()[0] === "csv"; //判断是否是 CSV
			var reader = new FileReader();
			var rABS = false; //二进制读取文件
			var wb; //读取完成的数据
			var aExcel2JsonData = []; //转换完成的JSON数据

			var _fnPromise = new Promise(function(resolve, reject) {
				reader.onload = function(e) {
					var data = e.target.result;
					wb = null;
					if (isCSV) {
						data = rABS ? new Uint8Array(data) : data;
						var str = cptable.utils.decode(936, data);
						wb = XLSX.read(str, {
							type: "string"
						});
					}

					if (!wb) {
						wb = rABS ? XLSX.read(btoa(fixdata(data)), {
							type: 'base64'
						}) : XLSX.read(data, {
							type: 'binary'
						});
					}

					var sheet0 = JSON.stringify(XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]])); //sheet0 的内容
					aExcel2JsonData.push(sheet0);
					resolve(aExcel2JsonData); //将每个sheet页的内容放在数组中
				};

				if (rABS) {
					reader.readAsArrayBuffer(oFile);
				} else {
					reader.readAsBinaryString(oFile);
				}
			});

			var excelData = [];
			//同步加载数据
			_fnPromise.then(function(result) {
				var aExcel = eval("(" + result[0] + ")");
				aExcel.forEach(function(value, index) {
					var oItem = {};
					for (var i = 0; i < aTableColumns.length; i++) {
						var sLabel = aTableColumns[i].label;
						var sProperty = aTableColumns[i].property;
						oItem[sProperty] = value[sLabel];
					}

					excelData.push(oItem);
				});

				fnDone(excelData);
			}.bind(this));
		},

		getTableColumns: function() {
			var oTable = this.getView().byId("resultTable");
			var aCols = [];
			if (!oTable) {
				return aCols;
			}

			var aBindingProperties = ["value", "selectedKey", "text", "selected"];
			var aColumns = oTable.getColumns();
			for (var i = 0; i < aColumns.length; i++) {
				var oColumn = aColumns[i];
				if (oColumn.getVisible() === false) { //隐藏字段不输出
					continue;
				}

				var sText = oColumn.getLabel().getText();
				var sProperty, sType;
				var oTemplate = oColumn.getTemplate();
				for (var k = 0; k < aBindingProperties.length; k++) {
					sProperty = aBindingProperties[k];
					//ComboBox取SelectedKey
					if (oTemplate instanceof sap.m.ComboBox && "value" === sProperty) {
						continue;
					}

					if (oTemplate.getBindingInfo(sProperty)) {
						var oBindingInfo = oTemplate.getBindingInfo(sProperty);
						sProperty = oBindingInfo.parts[0].path;
						sType = oBindingInfo.type ? oBindingInfo.type.sName : "";
						break;
					}
				}

				var sId = oColumn.getId();
				aCols.push({
					id: sId.substr(sId.lastIndexOf("--") + 2),
					label: sText,
					property: sProperty,
					type: sType
				});
			}

			return aCols;
		},
				
		_getNowFormatDate: function() {
			var dTimeStamp = new Date();
			var formatter = DateFormat.getDateInstance({
				style: "medium",
				UTC: false,
				pattern: "yyyy-MM-dd HH:mm:ss"//修改为24H, zhoum2019年10月29
			});
			
			return formatter.format(dTimeStamp, false);
		},
		
		isUTF8: function(bytes) {
			var i = 0;
			while (i < bytes.length) {
				if (( // ASCII
						bytes[i] == 0x09 ||
						bytes[i] == 0x0A ||
						bytes[i] == 0x0D ||
						(0x20 <= bytes[i] && bytes[i] <= 0x7E)
					)) {
					i += 1;
					continue;
				}

				if (( // non-overlong 2-byte
						(0xC2 <= bytes[i] && bytes[i] <= 0xDF) &&
						(0x80 <= bytes[i + 1] && bytes[i + 1] <= 0xBF)
					)) {
					i += 2;
					continue;
				}

				if (( // excluding overlongs
						bytes[i] == 0xE0 &&
						(0xA0 <= bytes[i + 1] && bytes[i + 1] <= 0xBF) &&
						(0x80 <= bytes[i + 2] && bytes[i + 2] <= 0xBF)
					) ||
					( // straight 3-byte
						((0xE1 <= bytes[i] && bytes[i] <= 0xEC) ||
							bytes[i] == 0xEE ||
							bytes[i] == 0xEF) &&
						(0x80 <= bytes[i + 1] && bytes[i + 1] <= 0xBF) &&
						(0x80 <= bytes[i + 2] && bytes[i + 2] <= 0xBF)
					) ||
					( // excluding surrogates
						bytes[i] == 0xED &&
						(0x80 <= bytes[i + 1] && bytes[i + 1] <= 0x9F) &&
						(0x80 <= bytes[i + 2] && bytes[i + 2] <= 0xBF)
					)
				) {
					i += 3;
					continue;
				}

				if (( // planes 1-3
						bytes[i] == 0xF0 &&
						(0x90 <= bytes[i + 1] && bytes[i + 1] <= 0xBF) &&
						(0x80 <= bytes[i + 2] && bytes[i + 2] <= 0xBF) &&
						(0x80 <= bytes[i + 3] && bytes[i + 3] <= 0xBF)
					) ||
					( // planes 4-15
						(0xF1 <= bytes[i] && bytes[i] <= 0xF3) &&
						(0x80 <= bytes[i + 1] && bytes[i + 1] <= 0xBF) &&
						(0x80 <= bytes[i + 2] && bytes[i + 2] <= 0xBF) &&
						(0x80 <= bytes[i + 3] && bytes[i + 3] <= 0xBF)
					) ||
					( // plane 16
						bytes[i] == 0xF4 &&
						(0x80 <= bytes[i + 1] && bytes[i + 1] <= 0x8F) &&
						(0x80 <= bytes[i + 2] && bytes[i + 2] <= 0xBF) &&
						(0x80 <= bytes[i + 3] && bytes[i + 3] <= 0xBF)
					)
				) {
					i += 4;
					continue;
				}
				return false;
			}

			return true;
		}

	});
});