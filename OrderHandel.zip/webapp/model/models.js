sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		
		getOrderCols: function(){
			return [{
				label: "订单编号",
				property: "tid"
			}, {
				label: "收货人姓名",
				property: "name"
			}, {
				label: "收货地址 ",
				property: "address"
			}, {
				label: "联系手机",
				property: "phone"
			}];
		},
		
		getOrderDetailCols: function(){
			return [{
				label: "订单编号",
				property: "tid"
			}, {
				label: "标题",
				property: "title"
			}, {
				label: "购买数量",
				property: "number"
			}];
		}

	};
});